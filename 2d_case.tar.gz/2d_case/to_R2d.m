function [R] = to_R2d( theta )
R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
end

